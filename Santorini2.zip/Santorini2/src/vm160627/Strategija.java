package vm160627;

import vm160627.Minimax.Cvor;

public abstract class Strategija {

	public abstract Cvor proracun(Igra i);
}
